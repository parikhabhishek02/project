var group__dmic =
[
    [ "DMIC DMA Driver", "group__dmic__dma__driver.html", "group__dmic__dma__driver" ],
    [ "DMIC Driver", "group__dmic__driver.html", "group__dmic__driver" ]
];