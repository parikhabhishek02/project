var group__debugconsole =
[
    [ "SWO", "group__SWO.html", null ],
    [ "Semihosting", "group__Semihosting.html", null ],
    [ "DEBUGCONSOLE_REDIRECT_TO_TOOLCHAIN", "group__debugconsole.html#gabb8f0adbec02f143b4f84d2eb42126df", null ],
    [ "DEBUGCONSOLE_REDIRECT_TO_SDK", "group__debugconsole.html#gac33031f28afa29dc8fe1718bbc86ee23", null ],
    [ "DEBUGCONSOLE_DISABLE", "group__debugconsole.html#gaf8f85fd102e4aedcee3d061dc2d3e0c2", null ],
    [ "SDK_DEBUGCONSOLE", "group__debugconsole.html#ga7fdd594efdc8374ecd8684ed758d6cec", null ],
    [ "SDK_DEBUGCONSOLE_UART", "group__debugconsole.html#gae225e7555c0f73bb3b705a22fe8b71e4", null ],
    [ "PRINTF", "group__debugconsole.html#gae1649fc947ca37a86917a08354f48d1a", null ],
    [ "printfCb", "group__debugconsole.html#gae9d851a9da87d7f21d8dd5a19f9eec7b", null ],
    [ "DbgConsole_Init", "group__debugconsole.html#ga12e50ee0450679fd8ca950a89338d366", null ],
    [ "DbgConsole_Deinit", "group__debugconsole.html#gad80e7aa70bbb3fce1a9168621372833e", null ],
    [ "DbgConsole_Printf", "group__debugconsole.html#ga1019139ac1c69fd62687250130c6ca7f", null ],
    [ "DbgConsole_Putchar", "group__debugconsole.html#gada572d86a06f028b5b1a5d0440f683e3", null ],
    [ "DbgConsole_Scanf", "group__debugconsole.html#ga6d87d10b03e4aaf8464206fe3829dd28", null ],
    [ "DbgConsole_Getchar", "group__debugconsole.html#ga11898c5015274863741c4f3f4d9edc08", null ],
    [ "DbgConsole_Flush", "group__debugconsole.html#ga3194467c3dae6c5015b8b29c3cc1db1e", null ],
    [ "StrFormatPrintf", "group__debugconsole.html#ga50b9d66ac2ba38b23b99dac4e81f4b8c", null ],
    [ "StrFormatScanf", "group__debugconsole.html#gafe318e0fd8d0f6ebad0c8a871a7a196f", null ]
];