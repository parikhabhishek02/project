var group__i2c__freertos__driver =
[
    [ "i2c_rtos_handle_t", "group__i2c__freertos__driver.html#structi2c__rtos__handle__t", [
      [ "base", "group__i2c__freertos__driver.html#a7bea8caaad98edc94b9d6bb5161bda77", null ],
      [ "drv_handle", "group__i2c__freertos__driver.html#a14a4eb4501e50ef62dfb3729e0881525", null ],
      [ "async_status", "group__i2c__freertos__driver.html#a78159621d4e8e5d635a5034840e9b061", null ],
      [ "mutex", "group__i2c__freertos__driver.html#ae4cc25f447861379d70d2e6a2807baf8", null ],
      [ "semaphore", "group__i2c__freertos__driver.html#aac7effed01f2bad89936114e26b96e3e", null ]
    ] ],
    [ "FSL_I2C_FREERTOS_DRIVER_VERSION", "group__i2c__freertos__driver.html#ga8a57a810d1c6632d3bf7dd2ea4e76ae5", null ],
    [ "I2C_RTOS_Init", "group__i2c__freertos__driver.html#ga2d8b0de9d5d807257ac91df157233cae", null ],
    [ "I2C_RTOS_Deinit", "group__i2c__freertos__driver.html#gabe3dc27604637a77cba04967097defb2", null ],
    [ "I2C_RTOS_Transfer", "group__i2c__freertos__driver.html#ga0b090779ab62f02149066a2325feb868", null ]
];