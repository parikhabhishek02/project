var group__mailbox =
[
    [ "FSL_MAILBOX_DRIVER_VERSION", "group__mailbox.html#gabf92577196ff009a06f8a1a7875eb5c0", null ],
    [ "mailbox_cpu_id_t", "group__mailbox.html#ga694d35969678f310c53495f230110789", null ],
    [ "MAILBOX_Init", "group__mailbox.html#ga070e4652978db2ccce1f27dd4cc429f4", null ],
    [ "MAILBOX_Deinit", "group__mailbox.html#ga868c90793f238c2c13f292b7386f6411", null ],
    [ "MAILBOX_SetValue", "group__mailbox.html#ga1ff6f115d93f4fedec0e5fdafe3dc5e2", null ],
    [ "MAILBOX_GetValue", "group__mailbox.html#gac0a0a1321a4bf7dcf282ab375d9dc9fc", null ],
    [ "MAILBOX_SetValueBits", "group__mailbox.html#ga8aa625fb6a0dcb0c2689a4cbec053236", null ],
    [ "MAILBOX_ClearValueBits", "group__mailbox.html#ga1f51e0e0995a53fdd64f2ceeea903117", null ],
    [ "MAILBOX_GetMutex", "group__mailbox.html#ga2e04445af3fd0aff73b564330348990a", null ],
    [ "MAILBOX_SetMutex", "group__mailbox.html#gabd0d6a42dee85726580a71e1503e8c01", null ]
];