var searchData=
[
  ['handle',['handle',['../group__i2c__slave__driver.html#ab74516c1edb1424ddb1554de7cae69bc',1,'i2c_slave_transfer_t']]],
  ['hour',['hour',['../group__rtc.html#af01da84e5dd15ca3713b29083a6893d2',1,'rtc_datetime_t']]]
];
