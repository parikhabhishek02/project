var searchData=
[
  ['architectural_20overview',['Architectural Overview',['../arch.html',1,'']]]
];
