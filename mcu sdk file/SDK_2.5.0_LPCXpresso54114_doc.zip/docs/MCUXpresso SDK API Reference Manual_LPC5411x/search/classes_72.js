var searchData=
[
  ['rtc_5fdatetime_5ft',['rtc_datetime_t',['../group__rtc.html#structrtc__datetime__t',1,'']]],
  ['rtos_5fusart_5fconfig',['rtos_usart_config',['../group__usart__freertos__driver.html#structrtos__usart__config',1,'']]]
];
