var searchData=
[
  ['base',['base',['../group__i2c__freertos__driver.html#a7bea8caaad98edc94b9d6bb5161bda77',1,'i2c_rtos_handle_t::base()'],['../group__spi__freertos__driver.html#ad3f15e078040cf1bd904907745e27eb6',1,'spi_rtos_handle_t::base()'],['../group__usart__dma__driver.html#ae9aae3e4298a725621990e5dcf91dc17',1,'_usart_dma_handle::base()'],['../group__usart__freertos__driver.html#ac2c11e2f563e88fd7235fd1c04c43695',1,'rtos_usart_config::base()'],['../group__usart__freertos__driver.html#aef0ac7c28d3207c4bd2a605d32163987',1,'usart_rtos_handle_t::base()'],['../group__dma.html#a84d667acc1301d6d56ae52573e4b6b87',1,'dma_handle_t::base()'],['../group__dmic__dma__driver.html#a1727f5ed3cff1bcca6b73f062e5f9b0c',1,'_dmic_dma_handle::base()']]],
  ['baudrate',['baudrate',['../group__usart__freertos__driver.html#add54d5367186b402624be17d78b85f5c',1,'rtos_usart_config']]],
  ['baudrate_5fbps',['baudRate_Bps',['../group__i2c__master__driver.html#a2186844dc87bcde999fc12005f4c550a',1,'i2c_master_config_t::baudRate_Bps()'],['../group__spi__driver.html#ae7695987e044d80983fd98a43812b1ea',1,'spi_master_config_t::baudRate_Bps()'],['../group__usart__driver.html#a5d2631bc772901b4114b01770f9bb337',1,'usart_config_t::baudRate_Bps()']]],
  ['bitcountperchar',['bitCountPerChar',['../group__usart__driver.html#ab964b3fbce4b824beff770a138fd4b6e',1,'usart_config_t']]],
  ['buf',['buf',['../group__i2c__master__driver.html#a9577474c0c4395355174df2b016108de',1,'_i2c_master_handle::buf()'],['../group__i2c__dma__driver.html#a65c4809f53c5df23e969217ea8daaee9',1,'_i2c_master_dma_handle::buf()']]],
  ['buffer',['buffer',['../group__usart__freertos__driver.html#a7ee13e3eb1fe35fc47e6732632305038',1,'rtos_usart_config']]],
  ['buffer_5fsize',['buffer_size',['../group__usart__freertos__driver.html#a0a13bc07966a8b84553e6010d4ea0e34',1,'rtos_usart_config']]],
  ['burst',['burst',['../group__dma.html#a66ad3f0d6159adbb560799bfb93da76a',1,'dma_channel_trigger_t']]],
  ['busspeed',['busSpeed',['../group__i2c__slave__driver.html#a14acc40a290c779fde0825f3a8bdbb25',1,'i2c_slave_config_t']]],
  ['bytesperframe',['bytesPerFrame',['../group__spi__dma__driver.html#ab83d82c084cba678e9ddb1135f89c29c',1,'_spi_dma_handle']]],
  ['bytewidth',['byteWidth',['../group__dma.html#a93c1b2f32e5e046cf10ba7e8b1c215ce',1,'dma_xfercfg_t']]]
];
