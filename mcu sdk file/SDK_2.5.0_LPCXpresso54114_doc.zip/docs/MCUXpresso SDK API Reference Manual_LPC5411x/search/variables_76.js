var searchData=
[
  ['valid',['valid',['../group__dma.html#a4a97a76d0d7266ee9cc8de82d19e5d81',1,'dma_xfercfg_t']]]
];
