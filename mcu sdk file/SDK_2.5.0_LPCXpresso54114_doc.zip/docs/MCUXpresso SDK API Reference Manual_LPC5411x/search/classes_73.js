var searchData=
[
  ['sctimer_5fconfig_5ft',['sctimer_config_t',['../group__sctimer.html#structsctimer__config__t',1,'']]],
  ['sctimer_5fpwm_5fsignal_5fparam_5ft',['sctimer_pwm_signal_param_t',['../group__sctimer.html#structsctimer__pwm__signal__param__t',1,'']]],
  ['spi_5fconfig_5ft',['spi_config_t',['../group__spi__driver.html#structspi__config__t',1,'']]],
  ['spi_5fdelay_5fconfig_5ft',['spi_delay_config_t',['../group__spi__driver.html#structspi__delay__config__t',1,'']]],
  ['spi_5fhalf_5fduplex_5ftransfer_5ft',['spi_half_duplex_transfer_t',['../group__spi__driver.html#structspi__half__duplex__transfer__t',1,'']]],
  ['spi_5fmaster_5fconfig_5ft',['spi_master_config_t',['../group__spi__driver.html#structspi__master__config__t',1,'']]],
  ['spi_5frtos_5fhandle_5ft',['spi_rtos_handle_t',['../group__spi__freertos__driver.html#structspi__rtos__handle__t',1,'']]],
  ['spi_5fslave_5fconfig_5ft',['spi_slave_config_t',['../group__spi__driver.html#structspi__slave__config__t',1,'']]],
  ['spi_5ftransfer_5ft',['spi_transfer_t',['../group__spi__driver.html#structspi__transfer__t',1,'']]]
];
