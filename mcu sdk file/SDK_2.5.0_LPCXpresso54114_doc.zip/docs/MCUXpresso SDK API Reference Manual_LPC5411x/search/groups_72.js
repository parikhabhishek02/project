var searchData=
[
  ['rtc_3a_20real_20time_20clock',['RTC: Real Time Clock',['../group__rtc.html',1,'']]]
];
