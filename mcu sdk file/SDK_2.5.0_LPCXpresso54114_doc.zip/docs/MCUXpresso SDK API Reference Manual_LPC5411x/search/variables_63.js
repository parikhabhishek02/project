var searchData=
[
  ['callback',['callback',['../group__i2c__slave__driver.html#a7229e894f762ead4bd08b4add49e6bc2',1,'_i2c_slave_handle::callback()'],['../group__spi__driver.html#a445e70d437c917e6af1b4037bdbb6a3f',1,'_spi_master_handle::callback()'],['../group__spi__dma__driver.html#a7dfc927b068cc0548da543dacfa34c3f',1,'_spi_dma_handle::callback()'],['../group__usart__driver.html#a50fd5afc23c86d872ee2a1d46bd4145e',1,'_usart_handle::callback()'],['../group__usart__dma__driver.html#abcd58fdcb247711f816f281da46e95e2',1,'_usart_dma_handle::callback()'],['../group__dma.html#a47a5c6af4c934cc9db355d394bb94f46',1,'dma_handle_t::callback()'],['../group__dmic__dma__driver.html#aa7d28d13ca279e07b003d829600cc21c',1,'_dmic_dma_handle::callback()']]],
  ['channel',['channel',['../group__dma.html#a7c068d330cc60423ee3fd86821221b85',1,'dma_handle_t']]],
  ['channelmask',['channelMask',['../group__lpc__adc.html#ab63c0a8803f4d02e040d55efd8d58e88',1,'adc_conv_seq_config_t']]],
  ['channelnumber',['channelNumber',['../group__lpc__adc.html#a6829bb748bc55409fed8615f6a40bb84',1,'adc_result_info_t']]],
  ['clockdividernumber',['clockDividerNumber',['../group__lpc__adc.html#abb59c0a54988e01653f80c8a59d18b1a',1,'adc_config_t']]],
  ['clockfreq_5fhz',['clockFreq_Hz',['../group__wwdt.html#a15e2f3ecd343280edfd8fbaa0bf8c9f4',1,'wwdt_config_t']]],
  ['clockmode',['clockMode',['../group__sctimer.html#aaba4aecfe1173c11bb8d77a8f9913196',1,'sctimer_config_t']]],
  ['clockselect',['clockSelect',['../group__sctimer.html#ad5d7a18f1b860f5fa7d0800d8e464127',1,'sctimer_config_t']]],
  ['clrtrig',['clrtrig',['../group__dma.html#ab30c2a4b2d436b966ba948edb010688f',1,'dma_xfercfg_t']]],
  ['complementin',['complementIn',['../group__crc.html#a9982af011e3e1fc9756dcee96281ebda',1,'crc_config_t']]],
  ['complementout',['complementOut',['../group__crc.html#a673b6508efa086da7b7bd537a876241e',1,'crc_config_t']]],
  ['completioncallback',['completionCallback',['../group__i2c__master__driver.html#a15b84b8a94c2b2e5ace0a695c79edd84',1,'_i2c_master_handle::completionCallback()'],['../group__i2c__dma__driver.html#a4d36b82522c60896cae7d86d187ecaf4',1,'_i2c_master_dma_handle::completionCallback()'],['../group__i2s__driver.html#a95bd70e36257e8fe9406d759d0ceb433',1,'_i2s_handle::completionCallback()'],['../group__i2s__dma__driver.html#a212f23416605bf198ace3bd5b6159768',1,'_i2s_dma_handle::completionCallback()']]],
  ['completionstatus',['completionStatus',['../group__i2c__slave__driver.html#a35adbf64ca65dd2c1b52f9260f5b9e90',1,'i2c_slave_transfer_t']]],
  ['configflags',['configFlags',['../group__spi__driver.html#a582eea734badd0049c98ea3cf89b3e4b',1,'spi_transfer_t::configFlags()'],['../group__spi__driver.html#a98635c2168a95161626ecdc0d22dab4d',1,'spi_half_duplex_transfer_t::configFlags()'],['../group__spi__driver.html#a798a5bb17e5685378c9f81ac945b0135',1,'_spi_master_handle::configFlags()']]]
];
