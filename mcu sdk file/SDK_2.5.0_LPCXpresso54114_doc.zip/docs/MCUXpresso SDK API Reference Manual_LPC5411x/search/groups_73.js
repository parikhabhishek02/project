var searchData=
[
  ['sctimer_3a_20sctimer_2fpwm_20_28sct_29',['SCTimer: SCTimer/PWM (SCT)',['../group__sctimer.html',1,'']]],
  ['semihosting',['Semihosting',['../group__Semihosting.html',1,'']]],
  ['spi_3a_20serial_20peripheral_20interface_20driver',['SPI: Serial Peripheral Interface Driver',['../group__spi.html',1,'']]],
  ['spi_20dma_20driver',['SPI DMA Driver',['../group__spi__dma__driver.html',1,'']]],
  ['spi_20driver',['SPI Driver',['../group__spi__driver.html',1,'']]],
  ['spi_20freertos_20driver',['SPI FreeRTOS driver',['../group__spi__freertos__driver.html',1,'']]],
  ['swo',['SWO',['../group__SWO.html',1,'']]],
  ['syscon_3a_20system_20configuration',['SYSCON: System Configuration',['../group__syscon.html',1,'']]]
];
