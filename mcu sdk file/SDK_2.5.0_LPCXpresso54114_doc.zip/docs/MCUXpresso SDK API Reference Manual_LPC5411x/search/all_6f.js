var searchData=
[
  ['onechannel',['oneChannel',['../group__i2s__driver.html#a31f47bae11e9bd15ddcf145f63487844',1,'i2s_config_t::oneChannel()'],['../group__i2s__driver.html#a7ca7ac0f7335eb401e1617bc4b6b784d',1,'_i2s_handle::oneChannel()']]],
  ['operation_5fmode_5ft',['operation_mode_t',['../group__dmic__driver.html#ga4dd0057f3dd624cfa8556f28956901b8',1,'fsl_dmic.h']]],
  ['osr',['osr',['../group__dmic__driver.html#aad5d855d02d730cbe678776620ae1b12',1,'dmic_channel_config_t']]],
  ['outcontrol',['outControl',['../group__ctimer.html#a0e8b29f0c0f74c5273942a521e3b16d6',1,'ctimer_match_config_t']]],
  ['outinitstate',['outInitState',['../group__sctimer.html#a3897b3b9321e3cecb05972fa68f947d5',1,'sctimer_config_t']]],
  ['outpininitstate',['outPinInitState',['../group__ctimer.html#a31ca8ee3406b7a17c793d94469e1e68d',1,'ctimer_match_config_t']]],
  ['output',['output',['../group__sctimer.html#ae030d75078255fd25e577c14d0a0fc80',1,'sctimer_pwm_signal_param_t']]],
  ['outputlogic',['outputLogic',['../group__lpc__gpio.html#a9d37ffd9a2943f10a91095759bd52da5',1,'gpio_pin_config_t']]],
  ['overrunflag',['overrunFlag',['../group__lpc__adc.html#a5d9fd2ad5f95c7b55a72ac1b5d10221f',1,'adc_result_info_t']]]
];
