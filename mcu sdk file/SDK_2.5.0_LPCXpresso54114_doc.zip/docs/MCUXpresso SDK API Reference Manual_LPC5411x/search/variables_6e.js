var searchData=
[
  ['nextdesc',['nextDesc',['../group__dma.html#a24f716a2b7775c1cb9a59b7c2374508b',1,'dma_transfer_config_t']]]
];
