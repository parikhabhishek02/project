var searchData=
[
  ['xfercfg',['xfercfg',['../group__dma.html#ad49be57eb231061b32b021a8854fe425',1,'dma_descriptor_t::xfercfg()'],['../group__dma.html#a365dbf9376f6927bc8b6527ce136914c',1,'dma_transfer_config_t::xfercfg()']]]
];
