var searchData=
[
  ['operation_5fmode_5ft',['operation_mode_t',['../group__dmic__driver.html#ga4dd0057f3dd624cfa8556f28956901b8',1,'fsl_dmic.h']]]
];
