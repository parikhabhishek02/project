var searchData=
[
  ['gainshft',['gainshft',['../group__dmic__driver.html#a450421370b638b59ffa272bae6071c2c',1,'dmic_channel_config_t']]]
];
