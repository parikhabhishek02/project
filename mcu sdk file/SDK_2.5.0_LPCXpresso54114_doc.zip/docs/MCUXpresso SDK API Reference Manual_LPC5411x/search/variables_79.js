var searchData=
[
  ['year',['year',['../group__rtc.html#a9d9b3f17954a41223c07440f08edaf74',1,'rtc_datetime_t']]]
];
