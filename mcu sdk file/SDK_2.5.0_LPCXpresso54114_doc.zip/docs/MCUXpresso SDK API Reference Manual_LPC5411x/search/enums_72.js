var searchData=
[
  ['rtc_5finterrupt_5fenable_5ft',['rtc_interrupt_enable_t',['../group__rtc.html#gabed8712e00907f44b420d274fd368738',1,'fsl_rtc.h']]],
  ['rtc_5fstatus_5fflags_5ft',['rtc_status_flags_t',['../group__rtc.html#gaa5edfafe0da586a9411fe4bafe32d9c5',1,'fsl_rtc.h']]]
];
