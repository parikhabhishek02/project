var searchData=
[
  ['adc_5fconfig_5ft',['adc_config_t',['../group__lpc__adc.html#structadc__config__t',1,'']]],
  ['adc_5fconv_5fseq_5fconfig_5ft',['adc_conv_seq_config_t',['../group__lpc__adc.html#structadc__conv__seq__config__t',1,'']]],
  ['adc_5fresult_5finfo_5ft',['adc_result_info_t',['../group__lpc__adc.html#structadc__result__info__t',1,'']]]
];
