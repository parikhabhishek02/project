var searchData=
[
  ['leftjust',['leftJust',['../group__i2s__driver.html#a1bd30d4ba4204ceff694883e65b0f658',1,'i2s_config_t']]],
  ['level',['level',['../group__sctimer.html#a8734c80f138c70349b10e6204d8db899',1,'sctimer_pwm_signal_param_t']]],
  ['linktonextdesc',['linkToNextDesc',['../group__dma.html#a8b4151dcf43270fbbeff39334048e7e1',1,'dma_descriptor_t']]],
  ['loopback',['loopback',['../group__usart__driver.html#a9892d7a138f2245bc9b7fe4e6c1652fb',1,'usart_config_t']]]
];
