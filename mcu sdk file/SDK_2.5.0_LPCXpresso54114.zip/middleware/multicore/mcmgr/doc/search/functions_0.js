var searchData=
[
  ['mcmgr_5fearlyinit',['MCMGR_EarlyInit',['../group__mcmgr.html#ga113834314ba8d727f8d601463ee71e88',1,'mcmgr.h']]],
  ['mcmgr_5fgetcorecount',['MCMGR_GetCoreCount',['../group__mcmgr.html#ga3c4b9d86b64af938a9f9c316028a03b9',1,'mcmgr.h']]],
  ['mcmgr_5fgetcoreproperty',['MCMGR_GetCoreProperty',['../group__mcmgr.html#gaae6f3eb8620f755a6a42b38952b59a20',1,'mcmgr.h']]],
  ['mcmgr_5fgetcurrentcore',['MCMGR_GetCurrentCore',['../group__mcmgr.html#gaf09a19de979b8d1cff3c53a4b9f1e233',1,'mcmgr.h']]],
  ['mcmgr_5fgetstartupdata',['MCMGR_GetStartupData',['../group__mcmgr.html#ga36fd13120448560dbbfe405eaa8d482a',1,'mcmgr.h']]],
  ['mcmgr_5fgetversion',['MCMGR_GetVersion',['../group__mcmgr.html#ga7b84c8f0aeb60f4a30cdc04eb188994f',1,'mcmgr.h']]],
  ['mcmgr_5finit',['MCMGR_Init',['../group__mcmgr.html#gab18e570ea8c466214b3725785d45aa35',1,'mcmgr.h']]],
  ['mcmgr_5fregisterevent',['MCMGR_RegisterEvent',['../group__mcmgr.html#ga08a4a13691e04c934998926adb277ae2',1,'mcmgr.h']]],
  ['mcmgr_5fstartcore',['MCMGR_StartCore',['../group__mcmgr.html#gac7850a1875bec8499300b1915a79a596',1,'mcmgr.h']]],
  ['mcmgr_5fstopcore',['MCMGR_StopCore',['../group__mcmgr.html#gab11c27fda1a646433b0d8cef19de6ee4',1,'mcmgr.h']]],
  ['mcmgr_5ftriggerevent',['MCMGR_TriggerEvent',['../group__mcmgr.html#ga75116754c189363da844f4a1a6da0f47',1,'mcmgr.h']]],
  ['mcmgr_5ftriggereventforce',['MCMGR_TriggerEventForce',['../group__mcmgr.html#gaab2ef35a249773dc0d5a431b4bdc4a5e',1,'mcmgr.h']]]
];
