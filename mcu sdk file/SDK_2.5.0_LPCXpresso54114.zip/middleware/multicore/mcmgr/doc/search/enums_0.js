var searchData=
[
  ['_5fmcmgr_5fcore',['_mcmgr_core',['../group__mcmgr.html#ga04ccbddec3c91482490e57e53afbeb6f',1,'mcmgr.h']]],
  ['_5fmcmgr_5fcore_5fproperty',['_mcmgr_core_property',['../group__mcmgr.html#gadc2ec0f3fda2d57dd3870335914b407f',1,'mcmgr.h']]],
  ['_5fmcmgr_5fcore_5ftype',['_mcmgr_core_type',['../group__mcmgr.html#gaad6bc70b5f869884191902e305d51a0a',1,'mcmgr.h']]],
  ['_5fmcmgr_5fevent_5ftype_5ft',['_mcmgr_event_type_t',['../group__mcmgr.html#ga0a45660b38a87ca65052a15d721a4949',1,'mcmgr.h']]],
  ['_5fmcmgr_5fstart_5fmode',['_mcmgr_start_mode',['../group__mcmgr.html#ga2b471b0504b78138baba1e17a05a9b9c',1,'mcmgr.h']]],
  ['_5fmcmgr_5fstatus',['_mcmgr_status',['../group__mcmgr.html#gaafc86a36cbeb3a8587cf1d03dfe095c8',1,'mcmgr.h']]]
];
