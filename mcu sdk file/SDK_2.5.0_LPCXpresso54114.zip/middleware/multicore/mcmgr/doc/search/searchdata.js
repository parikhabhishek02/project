var indexSectionsWithContent =
{
  0: "_km",
  1: "m",
  2: "m",
  3: "_m",
  4: "k",
  5: "m",
  6: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "functions",
  2: "typedefs",
  3: "enums",
  4: "enumvalues",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Functions",
  2: "Typedefs",
  3: "Enumerations",
  4: "Enumerator",
  5: "Modules",
  6: "Pages"
};

