var searchData=
[
  ['mcmgr_5fversion_5fenum',['mcmgr_version_enum',['../group__mcmgr.html#gabbf6e7e7978f537eaa72ea8e95bd0f1f',1,'mcmgr.h']]]
];
