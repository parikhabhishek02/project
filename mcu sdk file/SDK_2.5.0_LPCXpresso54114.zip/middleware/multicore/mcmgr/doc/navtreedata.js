var NAVTREE =
[
  [ "Multicore Manager (MCMGR) User's Guide", "index.html", [
    [ "MCMGR Component", "index.html", [
      [ "Usage of the MCMGR software component", "index.html#usage", null ],
      [ "Revision History", "index.html#revision_history", null ]
    ] ],
    [ "API Reference", "modules.html", "modules" ]
  ] ]
];

var NAVTREEINDEX =
[
"group__mcmgr.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';