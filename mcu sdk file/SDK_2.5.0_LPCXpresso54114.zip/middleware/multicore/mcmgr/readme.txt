multicore/mcmgr/readme.txt

The Multicore Manager (MCMGR) controls secondary core startup and shutdown.

Directory Structure

doc - Holds the documentation.
src - Holds source code for mcmgr. This code provides the API to control the second core.
