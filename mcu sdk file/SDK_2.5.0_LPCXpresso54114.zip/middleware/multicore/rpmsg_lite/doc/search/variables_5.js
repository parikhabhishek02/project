var searchData=
[
  ['sh_5fmem_5fbase',['sh_mem_base',['../group__rpmsg__lite.html#a79ea96087bf1897ccfd3eb2bccf2d78b',1,'rpmsg_lite_instance']]],
  ['sh_5fmem_5fremaining',['sh_mem_remaining',['../group__rpmsg__lite.html#ab2ce5bdfa263cdffc6563997e25acd50',1,'rpmsg_lite_instance']]],
  ['sh_5fmem_5ftotal',['sh_mem_total',['../group__rpmsg__lite.html#a17ae507517bfe8f585893b5f61b953f6',1,'rpmsg_lite_instance']]]
];
