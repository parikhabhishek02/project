var searchData=
[
  ['rl_5fept_5frx_5fcb_5ft',['rl_ept_rx_cb_t',['../group__rpmsg__lite.html#ga56f3f1cc5f980976ed1ab0d3ff59109a',1,'rpmsg_lite.h']]],
  ['rpmsg_5fns_5fnew_5fept_5fcb',['rpmsg_ns_new_ept_cb',['../group__rpmsg__ns.html#ga9c275f7b254e1e3b3a704f17137bd440',1,'rpmsg_ns.h']]],
  ['rpmsg_5fqueue_5fhandle',['rpmsg_queue_handle',['../group__rpmsg__queue.html#gaa6d197ceb3befc71d29f7b4a969d3d3e',1,'rpmsg_queue.h']]]
];
