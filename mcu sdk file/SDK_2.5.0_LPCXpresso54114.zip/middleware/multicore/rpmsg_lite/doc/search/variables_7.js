var searchData=
[
  ['vq_5fops',['vq_ops',['../group__rpmsg__lite.html#a0004491e023ed2e999182ba302fa32e5',1,'rpmsg_lite_instance']]]
];
