var group__config =
[
    [ "rpmsg_default_config.h", "rpmsg__default__config_8h.html", null ],
    [ "RL_MS_PER_INTERVAL", "group__config.html#gab1d9d807155917143be3785751c67f79", null ],
    [ "RL_BUFFER_PAYLOAD_SIZE", "group__config.html#ga4e0599085aeaa1fc8824015826c1e56b", null ],
    [ "RL_BUFFER_COUNT", "group__config.html#gab9a566c2e720eaa10348e84d35f8dde9", null ],
    [ "RL_API_HAS_ZEROCOPY", "group__config.html#ga931a9f16ee1aa309020c74cfe2eabf1f", null ],
    [ "RL_USE_STATIC_API", "group__config.html#ga287167874db5209903c7e391013ab485", null ],
    [ "RL_CLEAR_USED_BUFFERS", "group__config.html#ga8a47e919e7dcb7ba81ad9f315cf14d8d", null ],
    [ "RL_USE_MCMGR_IPC_ISR_HANDLER", "group__config.html#ga1b30d0352059e95ffe6075ade6373c16", null ],
    [ "RL_ASSERT", "group__config.html#ga1b73e9943f6d0786eee8e91020cdca29", null ]
];