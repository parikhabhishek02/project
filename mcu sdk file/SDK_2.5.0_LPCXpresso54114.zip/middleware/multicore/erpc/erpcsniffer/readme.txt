multicore/erpc/erpcsniffer/readme.txt

Directory Structure

src - Contains source code for erpcsniffer application.

Currently supported OS is Linux. Supported transport is tcp and serial.
