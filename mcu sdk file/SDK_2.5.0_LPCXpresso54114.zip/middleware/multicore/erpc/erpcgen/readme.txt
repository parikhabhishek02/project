multicore/erpc/erpcgen/readme.txt

Directory Structure

bin - Contains scripts used during building erpcgen application.

src - Contains source code for erpcgen application.

VisualStudio_v14 - Contains Visual Studio 2017 project files for building erpcgen application under windows.


Files

Makefile - Contains code to build erpcgen under Linux and OS X.
