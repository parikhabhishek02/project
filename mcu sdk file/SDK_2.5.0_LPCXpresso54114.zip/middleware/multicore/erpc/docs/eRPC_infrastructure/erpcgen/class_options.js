var class_options =
[
    [ "OptCtrl", "class_options.html#a455ec724e9fbd8a18cb85284a58774b5", [
      [ "DEFAULT", "class_options.html#a455ec724e9fbd8a18cb85284a58774b5a26cd53ef2503d91f05dd76a3a2d2dd4d", null ],
      [ "ANYCASE", "class_options.html#a455ec724e9fbd8a18cb85284a58774b5a72513bb31907833f42553e0b87b96fc8", null ],
      [ "QUIET", "class_options.html#a455ec724e9fbd8a18cb85284a58774b5a4d61357123cfb81ca1d85bf360bc3b10", null ],
      [ "PLUS", "class_options.html#a455ec724e9fbd8a18cb85284a58774b5ac483ab89c261a64567d7b192ca3e933b", null ],
      [ "SHORT_ONLY", "class_options.html#a455ec724e9fbd8a18cb85284a58774b5a42e2f53fb3e419dd5db83870b4982981", null ],
      [ "LONG_ONLY", "class_options.html#a455ec724e9fbd8a18cb85284a58774b5ab33a744d942ca0879a682bc295525ac4", null ],
      [ "NOGUESSING", "class_options.html#a455ec724e9fbd8a18cb85284a58774b5a07b810cf3728f88289deebd6a8769e0f", null ],
      [ "PARSE_POS", "class_options.html#a455ec724e9fbd8a18cb85284a58774b5aead50e0e93ecc08b89d561c09d688739", null ]
    ] ],
    [ "OptRC", "class_options.html#a39e2cec67d9659ada7fcb8a211223c73", [
      [ "ENDOPTS", "class_options.html#a39e2cec67d9659ada7fcb8a211223c73ae16374c97fa7f6d72213f03b51ccc133", null ],
      [ "BADCHAR", "class_options.html#a39e2cec67d9659ada7fcb8a211223c73ae4394bfd44b1bf978ab6a8ba5d8f9ddd", null ],
      [ "BADKWD", "class_options.html#a39e2cec67d9659ada7fcb8a211223c73a87b77241edb8885fa88e10f7579797fd", null ],
      [ "AMBIGUOUS", "class_options.html#a39e2cec67d9659ada7fcb8a211223c73a32b05d431cbbda0dd6060d2c96c2c571", null ],
      [ "POSITIONAL", "class_options.html#a39e2cec67d9659ada7fcb8a211223c73a5989dbdce33b76408c16bdb5b6852e7c", null ]
    ] ],
    [ "Options", "class_options.html#a7425a07001387b9e2f080a704cc7cca3", null ],
    [ "~Options", "class_options.html#a125c9676af5d22e04a53b517266e5f78", null ],
    [ "ctrls", "class_options.html#a966da6b84e47b7709ba43e8086b43f5c", null ],
    [ "ctrls", "class_options.html#aa6beab96e1692d11866a54484f145d2f", null ],
    [ "explicit_endopts", "class_options.html#a559f537279e0a2bd5f8468cb1159f7ce", null ],
    [ "name", "class_options.html#a20f463d775bec67dbbfdaa2af371073f", null ],
    [ "operator()", "class_options.html#ad31e1cd5a320e9feda434538b60eec6d", null ],
    [ "reset", "class_options.html#a0b329ebeeeb068b5f179fb434ae43e3a", null ],
    [ "usage", "class_options.html#a6751b0899db689a12139b2a69ebe63eb", null ]
];