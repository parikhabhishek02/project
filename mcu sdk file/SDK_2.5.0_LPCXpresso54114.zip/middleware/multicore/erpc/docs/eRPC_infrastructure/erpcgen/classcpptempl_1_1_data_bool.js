var classcpptempl_1_1_data_bool =
[
    [ "DataBool", "classcpptempl_1_1_data_bool.html#a030323a77253a98ec60879807d1fd49f", null ],
    [ "dump", "classcpptempl_1_1_data_bool.html#ac7f2750583e2bb91cfe7ca35ee625ef9", null ],
    [ "empty", "classcpptempl_1_1_data_bool.html#a50daa5871eee9531848fb72fa878937f", null ],
    [ "getint", "classcpptempl_1_1_data_bool.html#a1c3c330af7211e51e1380926681a8523", null ],
    [ "getvalue", "classcpptempl_1_1_data_bool.html#a0f9ba9d090f132512c9ce480f467ee67", null ]
];