var class_opt_argv_iter =
[
    [ "OptArgvIter", "class_opt_argv_iter.html#a4214d4e0e81ab511d84944fc1aa8b2d9", null ],
    [ "OptArgvIter", "class_opt_argv_iter.html#a514745995e159cd7057ec32a8d907ede", null ],
    [ "~OptArgvIter", "class_opt_argv_iter.html#a98343576877ef62c791445962752a15c", null ],
    [ "curr", "class_opt_argv_iter.html#a70d15a4bae80ed858537090aec78260e", null ],
    [ "index", "class_opt_argv_iter.html#aa92e7a667671e2dd77330142cbd9bf88", null ],
    [ "next", "class_opt_argv_iter.html#a8dde24972ceff7f80bee84d43f6c264f", null ],
    [ "operator()", "class_opt_argv_iter.html#a99914f7a15d154f4aab85229142ca8de", null ],
    [ "rewind", "class_opt_argv_iter.html#a6f69963903b9fda8fabfc27a442391ea", null ]
];