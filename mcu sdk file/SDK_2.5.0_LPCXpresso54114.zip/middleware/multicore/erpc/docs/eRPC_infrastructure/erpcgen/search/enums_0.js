var searchData=
[
  ['_5fbuiltin_5ftype',['_builtin_type',['../classerpcgen_1_1_builtin_type.html#a631f1f1e3e9aff50d2d18b6e1c288aac',1,'erpcgen::BuiltinType']]],
  ['_5fdata_5ftype',['_data_type',['../classerpcgen_1_1_data_type.html#a7b5230551817ee50d98d111d06212068',1,'erpcgen::DataType']]]
];
