var class_opt_iter =
[
    [ "OptIter", "class_opt_iter.html#ae371e388daffe03477d406a07aebb2e3", null ],
    [ "~OptIter", "class_opt_iter.html#a7e04e1baa2fefaed6334c08727c609ea", null ],
    [ "curr", "class_opt_iter.html#a83fee36a05864e23eebc91b251ac9743", null ],
    [ "next", "class_opt_iter.html#aa9b79aa55fa9e3cf948045ff2a59508c", null ],
    [ "operator()", "class_opt_iter.html#a039ef9ac21ffb563eedbc76cd42c5e02", null ]
];