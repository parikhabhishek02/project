var class_log =
[
    [ "SetOutputLevel", "class_log_1_1_set_output_level.html", "class_log_1_1_set_output_level" ]
];