var class_opt_istream_iter =
[
    [ "OptIstreamIter", "class_opt_istream_iter.html#a264d1dc2cfd63faf118b09c18c187b98", null ],
    [ "~OptIstreamIter", "class_opt_istream_iter.html#ae6fa1f1fa03f5846f1b4c4a870bdc006", null ],
    [ "curr", "class_opt_istream_iter.html#af32185c304138e10f374a011990dbc3d", null ],
    [ "next", "class_opt_istream_iter.html#acdd9ce5e2502fd9ddf6263a2d2f1eca2", null ],
    [ "operator()", "class_opt_istream_iter.html#ad4f55dbf941a4cd50ce894112b97fd7b", null ]
];