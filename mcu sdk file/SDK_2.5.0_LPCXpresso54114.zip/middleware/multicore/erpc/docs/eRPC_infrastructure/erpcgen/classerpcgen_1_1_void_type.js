var classerpcgen_1_1_void_type =
[
    [ "VoidType", "classerpcgen_1_1_void_type.html#a289d8f7fc680cd8ab895934b7b196500", null ],
    [ "getDescription", "classerpcgen_1_1_void_type.html#a329b76a4ef8e30637e7607883772b0e3", null ],
    [ "isVoid", "classerpcgen_1_1_void_type.html#a95819eb90801f50d7ad6b97e5dd7d7ba", null ]
];