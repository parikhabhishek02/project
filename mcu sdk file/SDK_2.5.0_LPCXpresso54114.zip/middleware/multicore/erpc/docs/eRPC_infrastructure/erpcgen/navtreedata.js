var NAVTREE =
[
  [ "eRPC Generator (erpcgen)", "index.html", [
    [ "About eRPC generator", "index.html", null ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"classcpptempl_1_1_data_int.html#a913d4934ef24fde10c0c23bc8756b9bd",
"classerpcgen_1_1_current_file_info.html#a9e0c30d0b5ca7d06ed4e255bb7a8d57a",
"classerpcgen_1_1_struct_member.html#a877241e3a6fdc53b31f62a8a14acbc61",
"classerpcgen_1_1erpcgen_tool.html#aaf4ae6398b015327af5f8844b11506a7"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';