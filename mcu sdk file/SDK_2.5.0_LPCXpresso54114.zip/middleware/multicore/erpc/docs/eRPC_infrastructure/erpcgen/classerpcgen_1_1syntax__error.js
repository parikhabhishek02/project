var classerpcgen_1_1syntax__error =
[
    [ "syntax_error", "classerpcgen_1_1syntax__error.html#a7730b0c9c500c0c5315bf9a28976b799", null ]
];