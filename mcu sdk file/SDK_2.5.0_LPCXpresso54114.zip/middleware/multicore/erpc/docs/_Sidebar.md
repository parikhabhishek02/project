### Table of Contents

* [Home-Introduction](Home)
* [IDL Reference](IDL-Reference)
* [Building and using erpcgen](erpcgen)
* [Infrastructure](eRPC-infrastructure)
* [Porting](Porting-Guide)
* [Getting Started](Getting-Started)
* [eRPC footprint](eRPC-footprint)
* [Building and using erpcsniffer](erpcsniffer)
* [Contributing](Contributing)
